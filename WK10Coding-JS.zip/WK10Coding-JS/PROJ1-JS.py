import math

def drawCircle(turtle, center, radius):
    # Move to the starting point of the circle
    turtle.penup()
    turtle.goto(center[0] + radius, center[1])
    turtle.pendown()

    # Calculate the distance to move for each step
    distance = 2.0 * math.pi * radius / 120.0

    # Draw the circle
    for i in range(120):
        turtle.forward(distance)
        turtle.right(3)
