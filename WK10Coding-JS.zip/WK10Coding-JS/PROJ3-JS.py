from turtle import Turtle, tracer, update

def drawFractalLine(t, distance, direction, level):
    """Draws a fractal line of the given level."""
    if level == 0:
        t.forward(distance)
    else:
        drawFractalLine(t, distance/3, direction, level-1)
        t.left(60)
        drawFractalLine(t, distance/3, direction+60, level-1)
        t.right(120)
        drawFractalLine(t, distance/3, direction-60, level-1)
        t.left(60)
        drawFractalLine(t, distance/3, direction, level-1)

def drawKochSnowflake(t, distance, level):
    """Draws a Koch snowflake of the given level."""
    for i in range(3):
        drawFractalLine(t, distance, i*120, level)
        t.right(120)

def main():
    level = int(input("Enter the level (0 or greater): "))
    t = Turtle()
    t.speed(0)
    t.hideturtle()
    drawKochSnowflake(t, 200, level)
    update()

if __name__ == "__main__":
    main()
